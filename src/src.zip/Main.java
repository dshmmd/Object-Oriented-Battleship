import view.RegisterMenu;

//thank you ali salesi boos
//thank you mohammad sadeghi boos
//thank you hirbod behnam boos
public class Main {

    public static void main(String[] args) {
        RegisterMenu.runRegisterMenu();
    }
}
