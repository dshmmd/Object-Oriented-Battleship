package model;

public enum CellType {
    EMPTY,
    MINE,
    SHIP,
    INVISIBLE_SHIP
}
